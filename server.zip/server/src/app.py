from flask import Flask, render_template, request, redirect
import os
import time
import script1
import list_items
import string, random
import pathlib

app = Flask(__name__)

app.config['UPLOAD_FOLDER'] = "./tmp"


def randomString(stringLength=8):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(stringLength))

def format_server_time():
    server_time = time.localtime()
    return time.strftime("%I:%M:%S %p", server_time)

@app.route('/')
def index():
    pa1 = pathlib.Path(__file__).parent.absolute
    pa2 = os.getcwd()  

    context = { 'server_time' : format_server_time(), 'pa1': str(pa1), 'pa2': str(pa2)}
    return render_template('index.html', context=context)

@app.route('/test', methods=['POST'])    
def test():    
    if request.method == 'POST':
        if 'pcfile' not in request.files:
            return redirect('/')
        file = request.files['pcfile']
        if file:                    
            filename = randomString(12)+".bic"        
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            theList = list_items.getItems(filename)
            os.remove('./tmp/'+filename)
            context = { 'list_items' : theList}
            return render_template('items.html', context=context)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 8080)))


