LANGUAGES = {
    0: "english",
    1: "french",
    2: "german",
    3: "italian",
    4: "spanish",
    5: "polish",
    128: "korean",
    129: "chinese_traditional",
    130: "chinese_simplified",
    131: "japanese",
}

GENDER = ['male', 'female']

ENGLISH = 0
FRENCH  = 1
GERMAN  = 2
ITALIAN = 3
SPANISH = 4
POLISH  = 5
KOREAN  = 128
CHINESE_TRADITION = 129
CHINESE_SIMPLIFIED = 130
JAPANESE = 131
